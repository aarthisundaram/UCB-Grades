import os
import shutil
def pptx_copy ():
   def selective_copy(source, destination, file_extension1=None, file_extension2=None,  ):
      for file in os.listdir(source):
         if file.endswith(file_extension1 or file_extension2):
            print(file)
            source_file = os.path.join(source, file)
            shutil.copy(source_file, destination)
            print("The following file has been copied", file)

   src = "C:/Users/AARTHI SUNDARAM/Downloads"
   dest = "C:/Users/AARTHI SUNDARAM/Documents/BootCamp_Exercise/Python-HW4/CyberSecurity-Notes"
   pattern1 = ".pptx"
   pattern2 = ".ppt"
   selective_copy(src, dest, pattern1, pattern2)

pptx_copy ()


