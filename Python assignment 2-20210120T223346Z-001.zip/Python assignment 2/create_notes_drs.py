import os
def main():
    path = "CyberSecurity-Notes"
    try:  
       os.mkdir(path)
    except OSError:  
       print ("Creation of the directory %s failed" % path)
    else:  
       print ("Successfully created the directory %s " % path)

    os.chdir(path)
    for i in range(1,25):
        tmpParentDir = "Week" + str(i)
        os.mkdir(tmpParentDir)
        os.chdir(tmpParentDir)
    for x in range(1,4):
        tmpChildDir = "Day" + str(x)
        os.mkdir(tmpChildDir)
        os.chdir("../")
        os.chdir("../")




main()



