import os
import shutil
def stu_activities():
   def selective_copy(source, destination, search_string=None):
      for file in os.listdir(source):
         if file.startswith(search_string):
            print(file)
            source_file = os.path.join(source, file)
            shutil.copy(source_file, destination)
            print("The following file has been copied", file)

   src = "C:/Users/AARTHI SUNDARAM/Downloads"
   dest = "C:/Users/AARTHI SUNDARAM/Documents/BootCamp_Exercise/Python-HW4/CyberSecurity-Notes"
   pattern = "Stu_"

   selective_copy(src, dest, pattern)

stu_activities()

   
   


