import hashlib
import csv

csv_input_file = open("C:/Users/AARTHI SUNDARAM/Documents/BootCamp_Exercise/UserInfo.csv")
contents = csv.reader(csv_input_file)
count = 0

# Creating the new csv file with write permission
with open("HashedUserInfo2.csv", "w", newline="") as myfile:
    csv_writer = csv.writer(myfile, quoting=csv.QUOTE_ALL)
    for row  in contents:
        password_cell = row[2]
        cc_cell = row[8]
        if count > 0:
            password_sha256 = hashlib.sha256()
            cc_sha256 = hashlib.sha256()
            # Hashing the password
            password_sha256.update(password_cell.encode('utf-8'))
            password_sha256_hash = password_sha256.hexdigest()
            row[2] = password_sha256_hash
            # Hashing the card number
            cc_sha256.update(cc_cell.encode('utf-8'))
            cc_sha256_hash = cc_sha256.hexdigest()
            row[8] = cc_sha256_hash 
        count = count + 1
        # Adding the row to the csv file
        csv_writer.writerow(row)
    myfile.close()
csv_input_file.close()
