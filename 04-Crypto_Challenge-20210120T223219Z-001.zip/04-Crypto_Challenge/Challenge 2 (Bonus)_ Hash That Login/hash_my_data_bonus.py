import hashlib
import csv

csv_input_file = open("C:/Users/AARTHI SUNDARAM/Documents/BootCamp_Exercise/HashedUserInfo.csv")
contents = csv.reader(csv_input_file)
row_count = sum(1 for line in contents)
csv_input_file.close()
 
# function to check the credentials
def check_user_info(username, password):
    count = 0
    csv_input_file = open("C:/Users/AARTHI SUNDARAM/Documents/BootCamp_Exercise/HashedUserInfo.csv")
    contents = csv.reader(csv_input_file)
    for row  in contents:
        if row[1] == username:
            # Hashing the password
            password_sha256 = hashlib.sha256()
            password_sha256.update(password.encode('utf-8'))
            password_sha256_hash = password_sha256.hexdigest()
            if row[2] == password_sha256_hash:
                print("Welcome Back " + row[0] + "!")
                print("Your address on file is: " + row[4] + " " + row[5] + " " + row[6] + " " + row[7])
                print("Your blance is: " + row[10])
                break
        count = count + 1
    if row_count == count:
        print("Sorry. Invalid login. Please try again.")
    csv_input_file.close()

# Get credentials from the user

while True:
    print("\n")
    print("Welcome to the HackSafe Bank!")
    print("================================")
    print("To login please provide the following details.")
    username = input("Enter your email address : ")
    password = input("Enter your password : ")
    check_user_info(username, password)
